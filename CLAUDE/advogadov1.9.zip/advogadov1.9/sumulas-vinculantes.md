SÚMULA VINCULANTE 1 Ofende a garantia constitucional do ato jurídico perfeito a decisão que, sem ponderar as circunstâncias do caso concreto, desconsidera a validez e a eficácia de acordo constante de termo de adesão instituído pela Lei Complementar nº .

SÚMULA VINCULANTE 2 É inconstitucional a lei ou ato normativo estadual ou distrital que disponha sobre sistemas de consórcios e sorteios, inclusive bingos e loterias.

SÚMULA VINCULANTE 3 Nos processos perante o Tribunal de Contas da União asseguram-se o contraditório e a ampla defesa quando da decisão puder resultar anulação ou revogação de ato administrativo que beneficie o interessado, excetuada a apreciação da legalidade do ato de concessão inicial de aposentadoria, reforma e pensão.

SÚMULA VINCULANTE 4 Salvo nos casos previstos na Constituição, o salário mínimo não pode ser usado como indexador de base de cálculo de vantagem de servidor público ou de empregado, nem ser substituído por decisão judicial.

SÚMULA VINCULANTE 5 A falta de defesa técnica por advogado no processo administrativo disciplinar não ofende a Constituição.

SÚMULA VINCULANTE 6 Não viola a Constituição o estabelecimento de remuneração inferior ao salário mínimo para as praças prestadoras de serviço militar inicial.

SÚMULA VINCULANTE 7 A norma do §3º do artigo 192 da Constituição, revogada pela Emenda Constitucional nº , que limitava a taxa de juros reais a 12% ao ano, tinha sua aplicação condicionada à edição de lei complementar.

SÚMULA VINCULANTE 8 São inconstitucionais o parágrafo único do artigo 5º do Decreto-Lei nº 1. e os artigos 45 e 46 da Lei nº 8., que tratam de prescrição e decadência de crédito tributário.

SÚMULA VINCULANTE 9 O disposto no artigo 127 da Lei nº 7. (Lei de Execução Penal) foi recebido pela ordem constitucional vigente, e não se lhe aplica o limite temporal previsto no caput do artigo 58.

SÚMULA VINCULANTE 10 Viola a cláusula de reserva de plenário (CF, artigo 97) a decisão de órgão fracionário de Tribunal que, embora não declare expressamente a inconstitucionalidade de lei ou ato normativo do poder público, afasta sua incidência, no todo ou em parte.

SÚMULA VINCULANTE 11 Só é lícito o uso de algemas em casos de resistência e de fundado receio de fuga ou de perigo à integridade física própria ou alheia, por parte do preso ou de terceiros, justificada a excepcionalidade por escrito, sob pena de responsabilidade disciplinar, civil e penal do agente ou da autoridade e de nulidade da prisão ou do ato processual a que se refere, sem prejuízo da responsabilidade civil do Estado.

SÚMULA VINCULANTE 12 A cobrança de taxa de matrícula nas universidades públicas viola o disposto no art. 206, IV, da Constituição Federal.

SÚMULA VINCULANTE 13 A nomeação de cônjuge, companheiro ou parente em linha reta, colateral ou por afinidade, até o terceiro grau, inclusive, da autoridade nomeante ou de servidor da mesma pessoa jurídica investido em cargo de direção, chefia ou assessoramento, para o exercício de cargo em comissão ou de confiança ou, ainda, de função gratificada na administração pública direta e indireta em qualquer dos Poderes da União, dos Estados, do Distrito Federal e dos 8 Municípios, compreendido o ajuste mediante designações recíprocas, viola a Constituição Federal.

SÚMULA VINCULANTE 14 É direito do defensor, no interesse do representado, ter acesso amplo aos elementos de prova que, já documentados em procedimento investigatório realizado por órgão com competência de polícia judiciária, digam respeito ao exercício do direito de defesa.

SÚMULA VINCULANTE 15 O cálculo de gratificações e outras vantagens do servidor público não incide sobre o abono utilizado para se atingir o salário mínimo.

SÚMULA VINCULANTE 16 Os artigos 7º, IV, e 39, § 3º (redação da EC ), da Constituição, referem-se ao total da remuneração percebida pelo servidor público.

SÚMULA VINCULANTE 17 Durante o período previsto no parágrafo 1º do artigo 100 da Constituição, não incidem juros de mora sobre os precatórios que nele sejam pagos.

SÚMULA VINCULANTE 18 A dissolução da sociedade ou do vínculo conjugal, no curso do mandato, não afasta a inelegibilidade prevista no § 7º do artigo 14 da Constituição Federal.

SÚMULA VINCULANTE 19 A taxa cobrada exclusivamente em razão dos serviços públicos de coleta, remoção e tratamento ou destinação de lixo ou resíduos provenientes de imóveis, não viola o artigo 145, II, da Constituição Federal.

SÚMULA VINCULANTE 20 A Gratificação de Desempenho de Atividade Técnico-Administrativa - GDATA, instituída pela Lei nº 10., deve ser deferida aos inativos nos valores correspondentes a 37,5 (trinta e sete vírgula cinco) pontos no período de fevereiro a maio de 2002 e, nos termos do artigo 5º, parágrafo único, da Lei 9 nº 10., no período de junho de 2002 até a conclusão dos efeitos do último ciclo de avaliação a que se refere o artigo 1º da Medida Provisória nº , a partir da qual passa a ser de 60 (sessenta) pontos.

SÚMULA VINCULANTE 21 É inconstitucional a exigência de depósito ou arrolamento prévios de dinheiro ou bens para admissibilidade de recurso administrativo.

SÚMULA VINCULANTE 22 A Justiça do Trabalho é competente para processar e julgar as ações de indenização por danos morais e patrimoniais decorrentes de acidente de trabalho propostas por empregado contra empregador, inclusive aquelas que ainda não possuíam sentença de mérito em primeiro grau quando da promulgação da Emenda Constitucional nº .

SÚMULA VINCULANTE 23 A Justiça do Trabalho é competente para processar e julgar ação possessória ajuizada em decorrência do exercício do direito de greve pelos trabalhadores da iniciativa privada.

SÚMULA VINCULANTE 24 Não se tipifica crime material contra a ordem tributária, previsto no art. 1º, incisos I a IV, da Lei nº 8., antes do lançamento definitivo do tributo.

SÚMULA VINCULANTE 25 É ilícita a prisão civil de depositário infiel, qualquer que seja a modalidade do depósito.

SÚMULA VINCULANTE 26 Para efeito de progressão de regime no cumprimento de pena por crime hediondo, ou equiparado, o juízo da execução observará a inconstitucionalidade do art. 2º da Lei n. 8.072, de 25 de julho de 1990, sem prejuízo de avaliar se o condenado preenche, ou não, os requisitos objetivos e subjetivos do benefício, podendo determinar, para tal fim, de modo fundamentado, a realização de exame criminológico.

SÚMULA VINCULANTE 27 Compete à Justiça estadual julgar causas entre consumidor e concessionária de serviço público de telefonia, quando a ANATEL não seja litisconsorte passiva necessária, assistente, nem opoente.

SÚMULA VINCULANTE 28 É inconstitucional a exigência de depósito prévio como requisito de admissibilidade de ação judicial na qual se pretenda discutir a exigibilidade de crédito tributário.

SÚMULA VINCULANTE 29 É constitucional a adoção, no cálculo do valor de taxa, de um ou mais elementos da base de cálculo própria de determinado imposto, desde que não haja integral identidade entre uma base e outra.

SÚMULA VINCULANTE 30 (A Súmula Vinculante 30 está pendente de publicação)

SÚMULA VINCULANTE 31 É inconstitucional a incidência do Imposto sobre Serviços de Qualquer Natureza – ISS sobre operações de locação de bens móveis.

SÚMULA VINCULANTE 32 O ICMS não incide sobre alienação de salvados de sinistro pelas seguradoras.

SÚMULA VINCULANTE 33 Aplicam-se ao servidor público, no que couber, as regras do regime geral da previdência social sobre aposentadoria especial de que trata o artigo 40, § 4º, inciso III da Constituição Federal, até a edição de lei complementar específica.

SÚMULA VINCULANTE 34 A Gratificação de Desempenho de Atividade de Seguridade Social e do Trabalho – GDASST, instituída pela Lei 10., deve ser estendida aos inativos no valor correspondente a 60 (sessenta) pontos, desde o advento da Medida Provisória , convertida na Lei 10., quando tais inativos façam jus à paridade constitucional (EC , e ).

SÚMULA VINCULANTE 35 A homologação da transação penal prevista no artigo 76 da Lei 9. não faz coisa julgada material e, descumpridas suas cláusulas, retoma-se a situação anterior, possibilitando-se ao Ministério Público a continuidade da persecução penal mediante oferecimento de denúncia ou requisição de inquérito policial.

SÚMULA VINCULANTE 36 Compete à Justiça Federal comum processar e julgar civil denunciado pelos crimes de falsificação e de uso de documento falso quando se tratar de falsificação da Caderneta de Inscrição e Registro (CIR) ou de Carteira de Habilitação de Amador (CHA), ainda que expedidas pela Marinha do Brasil.

SÚMULA VINCULANTE 37 Não cabe ao Poder Judiciário, que não tem função legislativa, aumentar vencimentos de servidores públicos sob o fundamento de isonomia.

SÚMULA VINCULANTE 38 É competente o Município para fixar o horário de funcionamento de estabelecimento comercial.

SÚMULA VINCULANTE 39 Compete privativamente à União legislar sobre vencimentos dos membros das polícias civil e militar e do corpo de bombeiros militar do Distrito Federal.

SÚMULA VINCULANTE 40 A contribuição confederativa de que trata o art. 8º, IV, da Constituição Federal, só é exigível dos filiados ao sindicato respectivo.

SÚMULA VINCULANTE 41 O serviço de iluminação pública não pode ser remunerado mediante taxa.

SÚMULA VINCULANTE 42 É inconstitucional a vinculação do reajuste de vencimentos de servidores estaduais ou municipais a índices federais de correção monetária.

SÚMULA VINCULANTE 43 É inconstitucional toda modalidade de provimento que propicie ao servidor investir-se, sem prévia aprovação em concurso público destinado ao seu provimento, em cargo que não integra a carreira na qual anteriormente investido.

SÚMULA VINCULANTE 44 Só por lei se pode sujeitar a exame psicotécnico a habilitação de candidato a cargo público.

SÚMULA VINCULANTE 45 A competência constitucional do Tribunal do Júri prevalece sobre o foro por prerrogativa de função estabelecido exclusivamente pela constituição estadual.

SÚMULA VINCULANTE 46 A definição dos crimes de responsabilidade e o estabelecimento das respectivas normas de processo e julgamento são da competência legislativa privativa da União.

SÚMULA VINCULANTE 47 Os honorários advocatícios incluídos na condenação ou destacados do montante principal devido ao credor consubstanciam verba de natureza alimentar cuja satisfação ocorrerá com a expedição de precatório ou requisição de pequeno valor, observada ordem especial restrita aos créditos dessa natureza.

SÚMULA VINCULANTE 48 Na entrada de mercadoria importada do exterior, é legítima a cobrança do ICMS por ocasião do desembaraço aduaneiro.

SÚMULA VINCULANTE 49 Ofende o princípio da livre concorrência lei municipal que impede a instalação de estabelecimentos comerciais do mesmo ramo em determinada área.

SÚMULA VINCULANTE 50 Norma legal que altera o prazo de recolhimento de obrigação tributária não se sujeita ao princípio da anterioridade.

SÚMULA VINCULANTE 51 O reajuste de 28,86%, concedido aos servidores militares pelas Leis e , estende-se aos servidores civis do poder executivo, observadas as eventuais compensações decorrentes dos reajustes diferenciados concedidos pelos mesmos diplomas legais.

SÚMULA VINCULANTE 52 Ainda quando alugado a terceiros, permanece imune ao IPTU o imóvel pertencente a qualquer das entidades referidas pelo art. 150, VI, "c", da Constituição Federal, desde que o valor dos aluguéis seja aplicado nas atividades para as quais tais entidades foram constituídas.

SÚMULA VINCULANTE 53 A competência da Justiça do Trabalho prevista no art. 114, VIII, da Constituição Federal alcança a execução de ofício das contribuições 14 previdenciárias relativas ao objeto da condenação constante das sentenças que proferir e acordos por ela homologados.

SÚMULA VINCULANTE 54 A medida provisória não apreciada pelo congresso nacional podia, até a Emenda Constitucional , ser reeditada dentro do seu prazo de eficácia de trinta dias, mantidos os efeitos de lei desde a primeira edição.

SÚMULA VINCULANTE 55 O direito ao auxílio-alimentação não se estende aos servidores inativos.

SÚMULA VINCULANTE 56 A falta de estabelecimento penal adequado não autoriza a manutenção do condenado em regime prisional mais gravoso, devendo-se observar, nessa hipótese, os parâmetros fixados no RE 641.320/RS.

SÚMULA VINCULANTE 57 A imunidade tributária constante do art. 150, VI, d, da CF/88 aplica-se à importação e comercialização, no mercado interno, do livro eletrônico (e- book) e dos suportes exclusivamente utilizados para fixá-los, como leitores de livros eletrônicos (e-readers), ainda que possuam funcionalidades acessórias.

SÚMULA VINCULANTE 58 Inexiste direito a crédito presumido de IPI relativamente à entrada de insumos isentos, sujeitos à alíquota zero ou não tributáveis, o que não contraria o princípio da não cumulatividade.