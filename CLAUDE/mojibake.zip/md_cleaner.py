#!/usr/bin/env python3
"""
Markdown Cleaner — Pipeline integrado de limpeza, encoding e extração jurídica.

Consolidado de:
  - corrigir_encoding.py   (EncodingDetector, MarkdownValidator)
  - limpar-md-integrado.py (GenericCleaner, QuestionProcessor, PipelineOrchestrator)

Melhorias v2:
  [1] charset-normalizer  — detecção de encoding por score de confiança (elimina falsos positivos de latin-1)
  [3] --diff              — visualização colorida das mudanças antes de salvar
  [4] --watch             — monitoramento contínuo do diretório com reprocessamento automático
  [5] --html              — relatório HTML auditável com métricas por arquivo
"""

import os
import re
import sys
import json
import time
import logging
import difflib
import textwrap
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Tuple, Optional
from pathlib import Path
from datetime import datetime

# ─────────────────────────────────────────────────────────────────────────────
# DEPENDÊNCIAS OPCIONAIS
# ─────────────────────────────────────────────────────────────────────────────
try:
    from charset_normalizer import from_path as cn_from_path
    HAS_CHARSET_NORMALIZER = True
except ImportError:
    HAS_CHARSET_NORMALIZER = False

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    HAS_WATCHDOG = True
except ImportError:
    HAS_WATCHDOG = False

# ─────────────────────────────────────────────────────────────────────────────
# LOGGING
# ─────────────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s | %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# CORES ANSI
# ─────────────────────────────────────────────────────────────────────────────
class Cor:
    VERDE   = "\033[32m"
    VERMELHO= "\033[31m"
    AMARELO = "\033[33m"
    AZUL    = "\033[34m"
    CIANO   = "\033[36m"
    NEGRITO = "\033[1m"
    DIM     = "\033[2m"
    RESET   = "\033[0m"

    @classmethod
    def suporte(cls) -> bool:
        """Retorna True se o terminal suporta cores ANSI."""
        return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()

    @classmethod
    def aplicar(cls, texto: str, *codigos: str) -> str:
        if not cls.suporte():
            return texto
        return "".join(codigos) + texto + cls.RESET


# ─────────────────────────────────────────────────────────────────────────────
# [MELHORIA 1] ENCODING DETECTOR — charset-normalizer com score de confiança
# ─────────────────────────────────────────────────────────────────────────────
class EncodingDetector:
    """
    Detecta e corrige encoding de arquivos de texto em pt-BR.

    v2: usa charset-normalizer (score de confiança) quando disponível.
    Fallback automático para tentativa sequencial caso a lib não esteja instalada.

    Threshold de confiança:
      chaos < 0.05  → encoding confiável (excelente)
      chaos < 0.15  → encoding provável (aceitável, emite aviso)
      chaos >= 0.15 → encoding incerto  (aviso forte, usa latin-1 como fallback seguro)
    """

    CHAOS_WARN  = 0.05   # acima disso → WARNING no log
    CHAOS_LIMIT = 0.15   # acima disso → fallback para latin-1

    # Caracteres cp1252 mal interpretados
    REPLACEMENTS = {
        "\x82": ",",   "\x84": '"',  "\x85": "...", "\x88": "^",
        "\x91": "'",   "\x92": "'",  "\x93": '"',   "\x94": '"',
        "\x95": "•",   "\x96": "-",  "\x97": "—",
        "\xa0": " ",   "\xa7": "§",  "\xa9": "©",   "\xaa": "ª",
        "\xab": "«",   "\xac": "¬",  "\xad": "",    "\xae": "®",
        "\xb0": "°",   "\xb1": "±",  "\xb2": "²",   "\xb3": "³",
        "\xb6": "¶",   "\xba": "º",  "\xbb": "»",
        "\xc0": "À",   "\xc1": "Á",  "\xc2": "Â",   "\xc3": "Ã",
        "\xc4": "Ä",   "\xc7": "Ç",  "\xc9": "É",   "\xca": "Ê",
        "\xd3": "Ó",   "\xd4": "Ô",  "\xd5": "Õ",   "\xda": "Ú",
        "\xe0": "à",   "\xe1": "á",  "\xe2": "â",   "\xe3": "ã",
        "\xe4": "ä",   "\xe7": "ç",  "\xe9": "é",   "\xea": "ê",
        "\xed": "í",   "\xf3": "ó",  "\xf4": "ô",   "\xf5": "õ",
        "\xfa": "ú",   "\xfc": "ü",
    }

    # UTF-8 mal decodificado como latin-1 (sequências duplas comuns pt-BR)
    PT_BR_CORRECT = {
        "Ã¡": "á",  "Ã©": "é",  "Ã­": "í",  "Ã³": "ó",  "Ãº": "ú",
        "Ã£": "ã",  "Ãµ": "õ",  "Ã¢": "â",  "Ãª": "ê",  "Ã´": "ô",
        "Ã§": "ç",  "Ã‡": "Ç",  "Ã…": "à",  "Ã‰": "É",  "Ãš": "Ú",
        "â\x80\x99": "'",  "â\x80\x9c": '"',  "â\x80\x9d": '"',
        "â\x80\x94": "—",  "â\x80\x93": "–",
    }

    ENCODINGS_FALLBACK = ["utf-8", "utf-8-sig", "latin-1", "cp1252", "iso-8859-1"]

    @classmethod
    def detect_and_correct(cls, filepath: str) -> Tuple[str, str, float]:
        """
        Lê arquivo com detecção automática e corrige caracteres problemáticos.

        Retorna:
            (encoding_usado: str, conteúdo_corrigido: str, chaos_score: float)
            chaos_score → 0.0 = perfeito, 1.0 = completamente caótico
        """
        if HAS_CHARSET_NORMALIZER:
            return cls._detect_with_normalizer(filepath)
        return cls._detect_fallback(filepath)

    @classmethod
    def _detect_with_normalizer(cls, filepath: str) -> Tuple[str, str, float]:
        """Detecção via charset-normalizer com score de confiança."""
        try:
            results = cn_from_path(filepath)
            best = results.best()

            if best is None:
                logger.warning(f"charset-normalizer não encontrou encoding para {filepath}; usando fallback")
                enc, content, _ = cls._detect_fallback(filepath)
                return enc, content, 1.0

            chaos = best.chaos
            encoding = best.encoding
            content = str(best)

            if chaos >= cls.CHAOS_LIMIT:
                logger.warning(
                    f"[ENC] Encoding incerto ({chaos:.1%}) em {Path(filepath).name} "
                    f"— detectado: {encoding}. Considere inspecionar o arquivo."
                )
            elif chaos >= cls.CHAOS_WARN:
                logger.info(
                    f"[ENC] Encoding provável ({chaos:.1%}): {encoding} — {Path(filepath).name}"
                )

            content = cls.correct_characters(content)
            return encoding, content, chaos

        except Exception as e:
            logger.warning(f"charset-normalizer falhou ({e}); usando fallback")
            return cls._detect_fallback(filepath)

    @classmethod
    def _detect_fallback(cls, filepath: str) -> Tuple[str, str, float]:
        """Tentativa sequencial de encodings (comportamento original)."""
        for enc in cls.ENCODINGS_FALLBACK:
            try:
                with open(filepath, "r", encoding=enc) as f:
                    content = f.read()
                content = cls.correct_characters(content)
                return enc, content, 0.0
            except (UnicodeDecodeError, UnicodeError):
                continue

        with open(filepath, "rb") as f:
            content = f.read().decode("utf-8", errors="replace")
        content = cls.correct_characters(content)
        return "utf-8 (com substituição)", content, 1.0

    @classmethod
    def correct_characters(cls, content: str) -> str:
        """Aplica todas as correções de caracteres em sequência."""
        for wrong, right in cls.REPLACEMENTS.items():
            content = content.replace(wrong, right)
        for wrong, right in cls.PT_BR_CORRECT.items():
            content = content.replace(wrong, right)
        # Remove caracteres de controle inválidos (preserva \t \n \r)
        content = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]", "", content)
        return content


# ─────────────────────────────────────────────────────────────────────────────
# RESULTADO DE LIMPEZA
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class CleaningResult:
    arquivo: str
    encoding_original: str = "utf-8"
    chaos_score: float = 0.0          # novo: confiança do encoding (0=perfeito, 1=incerto)
    limpezas: List[str] = field(default_factory=list)
    linhas_antes: int = 0
    linhas_depois: int = 0
    chars_antes: int = 0
    chars_depois: int = 0
    erro: Optional[str] = None
    salvo: bool = False
    diff_texto: str = ""              # novo: diff unificado (apenas se --diff)


# ─────────────────────────────────────────────────────────────────────────────
# MARKDOWN CLEANER — LIMPEZAS INTEGRADAS
# ─────────────────────────────────────────────────────────────────────────────
class MarkdownCleaner:
    """
    Aplica uma cadeia de limpezas a conteúdo Markdown.

    Transformações (em ordem):
      1.  BOM (byte order mark) → removido
      2.  CRLF → LF
      3.  Espaços duplos/triplos → único (fora de blocos de código)
      4.  Espaços no final de linha (trailing whitespace)
      5.  Linhas em branco excessivas → máx. 2 consecutivas
      6.  Espaço antes de pontuação: " ," " ." " ;" " :" → sem espaço
      7.  Headers sem espaço: ##Titulo → ## Titulo
      8.  Negrito/itálico com espaços internos: ** texto ** → **texto**
      9.  Links Markdown vazios: [texto]() → sinalizado no log
      10. Uma única \n no final do arquivo
    """

    def clean(self, content: str) -> Tuple[str, List[str]]:
        """Retorna (conteúdo limpo, lista de limpezas aplicadas)."""
        limpezas = []

        # 1. BOM
        if content.startswith("\ufeff"):
            content = content[1:]
            limpezas.append("BOM removido")

        # 2. CRLF → LF
        if "\r\n" in content:
            content = content.replace("\r\n", "\n")
            limpezas.append("CRLF → LF")

        # 3. Espaços duplos/triplos fora de blocos de código
        content, n = self._fix_multiple_spaces(content)
        if n:
            limpezas.append(f"Espaços múltiplos removidos ({n} ocorrências)")

        # 4. Trailing whitespace
        lines = content.split("\n")
        stripped = [line.rstrip() for line in lines]
        if stripped != lines:
            limpezas.append("Trailing whitespace removido")
        lines = stripped

        # 5. Linhas em branco excessivas (máx. 2)
        lines, n = self._fix_blank_lines(lines)
        if n:
            limpezas.append(f"Linhas em branco excessivas reduzidas ({n}x)")

        content = "\n".join(lines)

        # 6. Espaço antes de pontuação
        content, n = self._fix_space_before_punctuation(content)
        if n:
            limpezas.append(f"Espaço antes de pontuação corrigido ({n}x)")

        # 7. Headers sem espaço
        content, n = self._fix_headers(content)
        if n:
            limpezas.append(f"Headers normalizados ({n}x)")

        # 8. Negrito/itálico com espaços internos
        content, n = self._fix_bold_italic_spaces(content)
        if n:
            limpezas.append(f"Espaços em negrito/itálico removidos ({n}x)")

        # 9. Links vazios (apenas detecta, não altera)
        empty_links = re.findall(r"\[([^\]]+)\]\(\s*\)", content)
        if empty_links:
            limpezas.append(f"Links vazios detectados: {len(empty_links)} ([texto]())")

        # 10. Garante única \n no final
        content = content.rstrip("\n") + "\n"

        return content, limpezas

    # ── helpers ──────────────────────────────────────────────────────────────

    def _fix_multiple_spaces(self, content: str) -> Tuple[str, int]:
        """Remove espaços duplos/triplos, preservando blocos de código."""
        parts = re.split(r"(```[\s\S]*?```|`[^`]+`)", content)
        total = 0
        result = []
        for i, part in enumerate(parts):
            if i % 2 == 0:
                novo, n = re.subn(r" {2,}", " ", part)
                result.append(novo)
                total += n
            else:
                result.append(part)
        return "".join(result), total

    def _fix_blank_lines(self, lines: List[str]) -> Tuple[List[str], int]:
        """Reduz sequências de mais de 2 linhas em branco para exatamente 2."""
        result, consecutive, reductions = [], 0, 0
        for line in lines:
            if line.strip() == "":
                consecutive += 1
                if consecutive <= 2:
                    result.append(line)
                else:
                    reductions += 1
            else:
                consecutive = 0
                result.append(line)
        return result, reductions

    def _fix_space_before_punctuation(self, content: str) -> Tuple[str, int]:
        """Remove espaço indevido antes de ., , ; : em texto corrido."""
        content, n1 = re.subn(r" +([,;:])", r"\1", content)
        content, n2 = re.subn(r" +(\.(?=\s|$))", r"\1", content)
        return content, n1 + n2

    def _fix_headers(self, content: str) -> Tuple[str, int]:
        """Garante espaço entre # e o título: ##Titulo → ## Titulo."""
        return re.subn(r"^(#{1,6})([^#\s])", r"\1 \2", content, flags=re.MULTILINE)

    def _fix_bold_italic_spaces(self, content: str) -> Tuple[str, int]:
        """Remove espaços internos em **texto** e *texto*."""
        content, n1 = re.subn(r"\*\*\s+(.+?)\s+\*\*", r"**\1**", content)
        content, n2 = re.subn(r"\*\s+(.+?)\s+\*", r"*\1*", content)
        return content, n1 + n2


# ─────────────────────────────────────────────────────────────────────────────
# [MELHORIA 3] GERADOR DE DIFF
# ─────────────────────────────────────────────────────────────────────────────
class DiffGenerator:
    """
    Gera e exibe diffs coloridos entre o conteúdo original e o limpo.
    Comportamento idêntico a 'black --diff' ou 'prettier --check'.
    """

    @staticmethod
    def gerar(original: str, limpo: str, filename: str, n_contexto: int = 3) -> str:
        """
        Retorna string com diff unificado (sem cores — cores são aplicadas na exibição).
        n_contexto: linhas de contexto em volta de cada mudança.
        """
        linhas_orig  = original.splitlines(keepends=True)
        linhas_limpo = limpo.splitlines(keepends=True)
        diff = difflib.unified_diff(
            linhas_orig,
            linhas_limpo,
            fromfile=f"a/{filename}  (original)",
            tofile=f"b/{filename}  (limpo)",
            n=n_contexto,
        )
        return "".join(diff)

    @staticmethod
    def exibir(diff_texto: str, filename: str):
        """Imprime diff com cores ANSI se o terminal suportar."""
        if not diff_texto.strip():
            print(Cor.aplicar(f"  [=] {filename} — sem mudanças", Cor.DIM))
            return

        print(Cor.aplicar(f"\n  ── DIFF: {filename} ──", Cor.NEGRITO, Cor.AZUL))

        for linha in diff_texto.splitlines():
            if linha.startswith("+++") or linha.startswith("---"):
                print(Cor.aplicar(linha, Cor.NEGRITO))
            elif linha.startswith("@@"):
                print(Cor.aplicar(linha, Cor.CIANO))
            elif linha.startswith("+"):
                print(Cor.aplicar(linha, Cor.VERDE))
            elif linha.startswith("-"):
                print(Cor.aplicar(linha, Cor.VERMELHO))
            else:
                print(Cor.aplicar(linha, Cor.DIM))


# ─────────────────────────────────────────────────────────────────────────────
# ÁREAS JURÍDICAS
# ─────────────────────────────────────────────────────────────────────────────
AREAS = {
    "direito_tributario": {
        "titulo": "Direito Tributário",
        "headers": ["DIREITO TRIBUTARIO", "TRIBUTARIO", "DIREITO TRIBUTÁRIO"],
        "keywords": ["icms", "iptu", "iss", "ipva", "ipi", "ir", "cofins", "pis",
                     "csll", "ctn", "tributario", "tributário", "imposto", "tributo",
                     "fisco", "contribuinte", "lançamento", "obrigação tributária"],
    },
    "direito_administrativo": {
        "titulo": "Direito Administrativo",
        "headers": ["DIREITO ADMINISTRATIVO", "ADMINISTRATIVO"],
        "keywords": ["licitacao", "licitação", "servidor publico", "servidor público",
                     "improbidade", "concurso", "autarquia", "fundação pública",
                     "ato administrativo", "poder de polícia", "administração pública",
                     "lei 8112", "lei 8666", "lei 14133"],
    },
    "direito_civil": {
        "titulo": "Direito Civil",
        "headers": ["DIREITO CIVIL", "CIVIL"],
        "keywords": ["codigo civil", "código civil", "contratos", "obrigacoes",
                     "obrigações", "familia", "família", "propriedade", "posse",
                     "usucapião", "sucessões", "responsabilidade civil", "dano moral"],
    },
    "direito_penal": {
        "titulo": "Direito Penal",
        "headers": ["DIREITO PENAL", "PENAL"],
        "keywords": ["codigo penal", "código penal", "crime", "pena", "homicidio",
                     "homicídio", "furto", "roubo", "estelionato", "peculato",
                     "corrupção", "lavagem de dinheiro", "tráfico", "reclusão"],
    },
    "processual": {
        "titulo": "Direito Processual",
        "headers": ["PROCESSO", "PROCESSUAL", "CPC", "CPP"],
        "keywords": ["recurso", "apelacao", "apelação", "embargos", "sentenca",
                     "sentença", "liminar", "tutela", "mandado de segurança",
                     "habeas corpus", "agravo", "cpc", "cpp", "prazo processual"],
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# PROCESSADOR DE QUESTÕES
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class Questao:
    numero: str
    texto: str
    area: str = ""


class QuestionProcessor:
    """Extrai e classifica questões jurídicas de arquivos Markdown."""

    QUESTION_PATTERN = re.compile(
        r"(?:QUESTAO|Quest[^\d]+|QUESTÃO|Item|item|^\s*\d+[\.\)\-])\s*(\d+)",
        re.MULTILINE | re.IGNORECASE,
    )

    def __init__(self, areas: Dict[str, dict] = None):
        self.areas = areas or AREAS

    def extract(self, content: str) -> List[str]:
        """Extrai blocos de texto de cada questão."""
        content = re.sub(r"\r\n", "\n", content)
        content = re.sub(r"\n{3,}", "\n\n", content)
        questions = []
        matches = list(self.QUESTION_PATTERN.finditer(content))
        for i, match in enumerate(matches):
            start_idx = max(0, match.start() - 30)
            end_idx = matches[i + 1].start() if i + 1 < len(matches) else len(content)
            q_text = content[start_idx:end_idx].strip()
            q_text = self._clean_header(q_text)
            if 50 < len(q_text) < 10000:
                questions.append(q_text)
        return questions

    def classify(self, questions: List[str]) -> Dict[str, List[Questao]]:
        """Classifica questões por área jurídica usando score de keywords."""
        collected: Dict[str, List[Questao]] = {k: [] for k in self.areas}
        for q_text in questions:
            q_lower = q_text.lower()
            best_score, best_area = 0, None
            for area_key, config in self.areas.items():
                score = sum(2 for kw in config["keywords"] if kw.lower() in q_lower)
                score += sum(10 for h in config["headers"] if h.lower() in q_lower)
                if score > best_score:
                    best_score, best_area = score, area_key
            if best_area and best_score >= 3:
                m = self.QUESTION_PATTERN.search(q_text)
                num = m.group(1) if m else "?"
                collected[best_area].append(Questao(num, q_text, best_area))
        return collected

    def _clean_header(self, text: str) -> str:
        lines = text.split("\n")
        for i, line in enumerate(lines):
            if re.search(r"^##\s*Quest", line, re.IGNORECASE):
                return "\n".join(lines[i:]).strip()
        return text.strip()


# ─────────────────────────────────────────────────────────────────────────────
# [MELHORIA 5] GERADOR DE RELATÓRIO HTML
# ─────────────────────────────────────────────────────────────────────────────
class HTMLReportGenerator:
    """
    Gera relatório HTML autocontido com métricas, badges e tabela auditável.
    Não requer dependências externas — HTML puro.
    """

    @staticmethod
    def gerar(results: List[CleaningResult], diretorio: str, dry_run: bool) -> str:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        total       = len(results)
        com_erro    = sum(1 for r in results if r.erro)
        salvos      = sum(1 for r in results if r.salvo)
        total_clean = sum(len(r.limpezas) for r in results)
        chars_saved = sum(r.chars_antes - r.chars_depois for r in results if not r.erro)

        def badge(texto, cor):
            return f'<span class="badge" style="background:{cor}">{texto}</span>'

        def chaos_badge(score):
            if score <= 0.05:
                return badge(f"⬤ {score:.2f}", "#16a34a")
            elif score <= 0.15:
                return badge(f"⬤ {score:.2f}", "#ca8a04")
            else:
                return badge(f"⬤ {score:.2f}", "#dc2626")

        rows = ""
        for r in results:
            if r.erro:
                status_html = badge("✘ ERRO", "#dc2626")
            elif r.limpezas:
                status_html = badge("✔ LIMPO", "#16a34a")
            else:
                status_html = badge("= INTACTO", "#6b7280")

            reducao = (
                f"{(1 - r.chars_depois / r.chars_antes) * 100:.1f}%"
                if r.chars_antes > 0 else "—"
            )

            limpezas_html = (
                "<ul>" + "".join(f"<li>{l}</li>" for l in r.limpezas) + "</ul>"
                if r.limpezas else "<span class='dim'>nenhuma</span>"
            )

            erro_html = (
                f"<div class='erro'>{r.erro}</div>" if r.erro else ""
            )

            rows += f"""
            <tr>
                <td class="mono">{r.arquivo}</td>
                <td>{status_html}</td>
                <td class="mono">{r.encoding_original}</td>
                <td>{chaos_badge(r.chaos_score)}</td>
                <td class="num">{r.linhas_antes:,} → {r.linhas_depois:,}</td>
                <td class="num">{reducao}</td>
                <td class="small">{limpezas_html}{erro_html}</td>
            </tr>"""

        modo_badge = (
            badge("DRY-RUN", "#7c3aed") if dry_run else badge("PRODUÇÃO", "#0369a1")
        )

        html = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Markdown Cleaner — Relatório {timestamp}</title>
  <style>
    :root {{
      --bg:      #f9fafb;
      --surface: #ffffff;
      --border:  #e5e7eb;
      --text:    #111827;
      --sub:     #6b7280;
      --mono:    "SFMono-Regular", Consolas, monospace;
    }}
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: var(--bg); color: var(--text);
      padding: 2rem; font-size: 14px; line-height: 1.5;
    }}
    h1 {{ font-size: 1.4rem; font-weight: 700; margin-bottom: 0.25rem; }}
    .meta {{ color: var(--sub); font-size: 0.85rem; margin-bottom: 2rem; }}
    .cards {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
      gap: 1rem; margin-bottom: 2rem;
    }}
    .card {{
      background: var(--surface); border: 1px solid var(--border);
      border-radius: 8px; padding: 1rem; text-align: center;
    }}
    .card .num {{ font-size: 2rem; font-weight: 700; }}
    .card .label {{ color: var(--sub); font-size: 0.75rem; text-transform: uppercase; }}
    table {{
      width: 100%; border-collapse: collapse;
      background: var(--surface); border: 1px solid var(--border);
      border-radius: 8px; overflow: hidden;
    }}
    th {{
      background: #f3f4f6; font-weight: 600;
      padding: 0.6rem 0.75rem; text-align: left;
      font-size: 0.75rem; text-transform: uppercase; color: var(--sub);
      border-bottom: 1px solid var(--border);
    }}
    td {{
      padding: 0.6rem 0.75rem; border-bottom: 1px solid var(--border);
      vertical-align: top;
    }}
    tr:last-child td {{ border-bottom: none; }}
    tr:hover td {{ background: #f9fafb; }}
    .mono {{ font-family: var(--mono); font-size: 0.82rem; }}
    .small {{ font-size: 0.82rem; }}
    .small ul {{ padding-left: 1rem; }}
    .small li {{ margin-bottom: 0.15rem; color: #374151; }}
    .num {{ text-align: right; font-family: var(--mono); }}
    .dim {{ color: var(--sub); }}
    .erro {{ color: #dc2626; font-family: var(--mono); font-size: 0.8rem; margin-top: 0.25rem; }}
    .badge {{
      display: inline-block; padding: 0.15rem 0.5rem;
      border-radius: 999px; color: #fff; font-size: 0.75rem; font-weight: 600;
    }}
    .footer {{
      margin-top: 1.5rem; color: var(--sub); font-size: 0.8rem; text-align: center;
    }}
  </style>
</head>
<body>
  <h1>📄 Markdown Cleaner — Relatório de Processamento</h1>
  <p class="meta">
    Gerado em: <strong>{timestamp}</strong> &nbsp;|&nbsp;
    Diretório: <code>{diretorio}</code> &nbsp;|&nbsp;
    Modo: {modo_badge}
    {"&nbsp;|&nbsp; <strong style='color:#ca8a04'>⚠ charset-normalizer não instalado — usando fallback</strong>" if not HAS_CHARSET_NORMALIZER else ""}
  </p>

  <div class="cards">
    <div class="card"><div class="num">{total}</div><div class="label">Arquivos</div></div>
    <div class="card"><div class="num">{salvos}</div><div class="label">Salvos</div></div>
    <div class="card"><div class="num" style="color:#dc2626">{com_erro}</div><div class="label">Erros</div></div>
    <div class="card"><div class="num">{total_clean}</div><div class="label">Limpezas</div></div>
    <div class="card"><div class="num">{chars_saved:,}</div><div class="label">Chars removidos</div></div>
  </div>

  <table>
    <thead>
      <tr>
        <th>Arquivo</th>
        <th>Status</th>
        <th>Encoding</th>
        <th title="0.0=perfeito 1.0=incerto">Chaos</th>
        <th>Linhas</th>
        <th>Redução</th>
        <th>Limpezas aplicadas</th>
      </tr>
    </thead>
    <tbody>{rows}</tbody>
  </table>

  <p class="footer">
    Markdown Cleaner v2 &nbsp;·&nbsp;
    charset-normalizer: {"✔ ativo" if HAS_CHARSET_NORMALIZER else "✘ não instalado (pip install charset-normalizer)"} &nbsp;·&nbsp;
    watchdog: {"✔ ativo" if HAS_WATCHDOG else "✘ não instalado (pip install watchdog)"}
  </p>
</body>
</html>"""
        return html


# ─────────────────────────────────────────────────────────────────────────────
# [MELHORIA 4] HANDLER DO WATCHDOG
# ─────────────────────────────────────────────────────────────────────────────
if HAS_WATCHDOG:
    class _MDFileHandler(FileSystemEventHandler):
        """
        Handler do watchdog: reprocessa qualquer .md modificado ou criado,
        excluindo arquivos gerados pelo próprio pipeline.
        """

        def __init__(self, orchestrator: "PipelineOrchestrator", show_diff: bool = False):
            super().__init__()
            self.orchestrator = orchestrator
            self.show_diff = show_diff
            self._debounce: Dict[str, float] = {}
            self._debounce_delay = 1.0  # segundos

        def _deve_processar(self, path: str) -> bool:
            p = Path(path)
            if not p.suffix == ".md":
                return False
            if p.name.startswith("questoes_"):
                return False
            if p.name.startswith("relatorio"):
                return False
            if self.orchestrator.sufixo in p.stem:
                return False
            return True

        def _debounced(self, path: str) -> bool:
            """Retorna True somente se passaram > debounce_delay segundos desde o último evento."""
            now = time.time()
            ultimo = self._debounce.get(path, 0)
            if now - ultimo < self._debounce_delay:
                return False
            self._debounce[path] = now
            return True

        def on_modified(self, event):
            if not event.is_directory and self._deve_processar(event.src_path):
                if self._debounced(event.src_path):
                    print(Cor.aplicar(
                        f"\n  [WATCH] Modificado: {Path(event.src_path).name}",
                        Cor.AMARELO, Cor.NEGRITO,
                    ))
                    self.orchestrator._processar_arquivo(
                        Path(event.src_path), show_diff=self.show_diff
                    )

        def on_created(self, event):
            if not event.is_directory and self._deve_processar(event.src_path):
                if self._debounced(event.src_path):
                    print(Cor.aplicar(
                        f"\n  [WATCH] Novo arquivo: {Path(event.src_path).name}",
                        Cor.VERDE, Cor.NEGRITO,
                    ))
                    self.orchestrator._processar_arquivo(
                        Path(event.src_path), show_diff=self.show_diff
                    )


# ─────────────────────────────────────────────────────────────────────────────
# ORQUESTRADOR DO PIPELINE
# ─────────────────────────────────────────────────────────────────────────────
class PipelineOrchestrator:
    """Orquestra o pipeline completo: encoding → limpeza → extração → relatório."""

    def __init__(
        self,
        base_dir: str,
        dry_run: bool = False,
        sufixo: str = "_limpo",
    ):
        self.base_dir = Path(base_dir)
        self.dry_run  = dry_run
        self.sufixo   = sufixo
        self.cleaner  = MarkdownCleaner()
        self.diff_gen = DiffGenerator()
        self.results: List[CleaningResult] = []

        # [MELHORIA 2] Merge de áreas extras via areas_extra.json na pasta processada
        areas_ativas = dict(AREAS)
        extra_path = self.base_dir / "areas_extra.json"
        if extra_path.exists():
            try:
                extra = json.loads(extra_path.read_text(encoding="utf-8"))
                areas_ativas = {**AREAS, **extra}
                logger.info(
                    f"[AREAS] {len(extra)} área(s) extra(s) carregada(s) "
                    f"de areas_extra.json → total: {len(areas_ativas)}"
                )
            except json.JSONDecodeError as e:
                logger.warning(
                    f"[AREAS] areas_extra.json inválido ({e}) — usando apenas áreas padrão"
                )

        self.question_processor = QuestionProcessor(areas_ativas)

    # ── interface pública ─────────────────────────────────────────────────────

    def run(self, extrair_questoes: bool = True, show_diff: bool = False) -> List[CleaningResult]:
        """Executa pipeline completo (fase 1: limpeza; fase 2: questões)."""
        self._cabecalho()
        md_files = self._coletar_arquivos()
        if not md_files:
            print("  [AVISO] Nenhum arquivo .md encontrado.")
            return []

        print(f"  [INFO] {len(md_files)} arquivo(s) encontrado(s)\n")

        for filepath in md_files:
            result = self._processar_arquivo(filepath, show_diff=show_diff)
            self.results.append(result)

        if extrair_questoes:
            self._extrair_questoes(md_files)

        self._exibir_relatorio()
        return self.results

    def salvar_relatorio_json(self, output_path: str):
        """Salva relatório de limpeza em JSON."""
        # Remove diff_texto do JSON para não poluir (pode ser grande)
        registros = []
        for r in self.results:
            d = asdict(r)
            d.pop("diff_texto", None)
            registros.append(d)

        data = {
            "timestamp":  datetime.now().isoformat(),
            "diretorio":  str(self.base_dir),
            "dry_run":    self.dry_run,
            "charset_normalizer_ativo": HAS_CHARSET_NORMALIZER,
            "arquivos":   registros,
        }
        Path(output_path).write_text(
            json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        print(f"\n  [OK] Relatório JSON salvo em: {output_path}")

    def salvar_relatorio_html(self, output_path: str):
        """[MELHORIA 5] Salva relatório HTML auditável."""
        html = HTMLReportGenerator.gerar(self.results, str(self.base_dir), self.dry_run)
        Path(output_path).write_text(html, encoding="utf-8")
        print(f"\n  [OK] Relatório HTML salvo em: {output_path}")

    def iniciar_watch(self, show_diff: bool = False):
        """[MELHORIA 4] Monitora o diretório e reprocessa .md ao detectar mudanças."""
        if not HAS_WATCHDOG:
            print(
                "[ERRO] watchdog não instalado. "
                "Execute: pip install watchdog"
            )
            sys.exit(1)

        self._cabecalho()
        print(Cor.aplicar(
            f"  [WATCH] Monitorando: {self.base_dir}\n"
            f"  [WATCH] Pressione Ctrl+C para parar.\n",
            Cor.AMARELO, Cor.NEGRITO,
        ))

        handler  = _MDFileHandler(self, show_diff=show_diff)
        observer = Observer()
        observer.schedule(handler, str(self.base_dir), recursive=False)
        observer.start()

        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print(Cor.aplicar("\n  [WATCH] Interrompido pelo usuário.", Cor.AMARELO))
            observer.stop()
        observer.join()

    # ── privados ─────────────────────────────────────────────────────────────

    def _cabecalho(self):
        print(f"\n{'='*60}")
        print(f"  MARKDOWN CLEANER PIPELINE  v2")
        print(f"  Diretório: {self.base_dir}")
        print(f"  Modo: {'DRY-RUN (sem salvar)' if self.dry_run else 'PRODUÇÃO'}")
        if HAS_CHARSET_NORMALIZER:
            print(f"  Encoding: charset-normalizer ativo")
        else:
            print(f"  Encoding: fallback sequencial (pip install charset-normalizer para melhor detecção)")
        print(f"{'='*60}\n")

    def _coletar_arquivos(self) -> List[Path]:
        """Coleta .md excluindo arquivos gerados pelo próprio pipeline."""
        return [
            f for f in self.base_dir.glob("*.md")
            if not f.name.startswith("questoes_")
            and not f.name.startswith("relatorio")
            and not f.name.endswith(f"{self.sufixo}.md")
        ]

    def _processar_arquivo(self, filepath: Path, show_diff: bool = False) -> CleaningResult:
        """Processa um único arquivo: encoding → limpeza → (diff opcional) → salva."""
        result = CleaningResult(arquivo=filepath.name)
        print(f"  [ARQ] {filepath.name}")

        try:
            # [MELHORIA 1] Detecção com score de confiança
            encoding, content, chaos = EncodingDetector.detect_and_correct(str(filepath))
            result.encoding_original = encoding
            result.chaos_score       = chaos
            result.chars_antes       = len(content)
            result.linhas_antes      = content.count("\n")

            if encoding not in ("utf-8", "utf-8-sig"):
                result.limpezas.append(f"Encoding corrigido: {encoding} → utf-8")
                print(f"        [ENC] {encoding} → utf-8  (chaos={chaos:.2f})")
            elif chaos > EncodingDetector.CHAOS_WARN:
                print(
                    Cor.aplicar(
                        f"        [ENC] Atenção: encoding incerto (chaos={chaos:.2f})",
                        Cor.AMARELO,
                    )
                )

            cleaned, limpezas = self.cleaner.clean(content)
            result.limpezas.extend(limpezas)
            result.chars_depois  = len(cleaned)
            result.linhas_depois = cleaned.count("\n")

            for l in limpezas:
                print(f"        [FIX] {l}")

            # [MELHORIA 3] Gera e exibe diff se solicitado
            if show_diff or self.dry_run:
                diff_texto = DiffGenerator.gerar(content, cleaned, filepath.name)
                result.diff_texto = diff_texto
                DiffGenerator.exibir(diff_texto, filepath.name)

            # Salva (somente se não for dry-run)
            if not self.dry_run and cleaned.strip():
                output_path = filepath.parent / f"{filepath.stem}{self.sufixo}.md"
                output_path.write_text(cleaned, encoding="utf-8")
                result.salvo = True
                print(f"        [OK] → {output_path.name}")
            elif self.dry_run:
                print(Cor.aplicar("        [DRY] Não salvo (dry-run)", Cor.DIM))

        except Exception as e:
            result.erro = str(e)
            print(Cor.aplicar(f"        [ERRO] {e}", Cor.VERMELHO))

        return result

    def _extrair_questoes(self, md_files: List[Path]):
        print(f"\n{'='*60}")
        print(f"  FASE 2: EXTRAÇÃO DE QUESTÕES JURÍDICAS")
        print(f"{'='*60}\n")

        if not self.dry_run:
            for f in self.base_dir.glob("questoes_*.md"):
                f.unlink()

        global_stats: Dict[str, int] = {k: 0 for k in self.question_processor.areas}

        for filepath in md_files:
            print(f"  [ARQ] {filepath.name}")
            try:
                _, content, _ = EncodingDetector.detect_and_correct(str(filepath))
            except Exception as e:
                print(f"        [ERRO] {e}")
                continue

            questions = self.question_processor.extract(content)
            if not questions:
                print(f"        [INFO] Nenhuma questão encontrada")
                continue

            print(f"        [QTD] {len(questions)} questão(ões)")
            classified = self.question_processor.classify(questions)

            for area_key, questoes in classified.items():
                if not questoes:
                    continue
                output_path = self.base_dir / f"questoes_{area_key}.md"
                mode = "a" if output_path.exists() else "w"
                if not self.dry_run:
                    with open(output_path, mode, encoding="utf-8") as f:
                        if mode == "w":
                            f.write(f"# {self.question_processor.areas[area_key]['titulo']}\n\n")
                            f.write("> Extraídas automaticamente pelo Markdown Cleaner\n\n---\n\n")
                        f.write(f"## {filepath.name}\n\n")
                        for q in questoes:
                            f.write(f"### Questão {q.numero}\n\n{q.texto}\n\n---\n\n")
                global_stats[area_key] += len(questoes)
                print(f"        [SALVO] {len(questoes)}x em questoes_{area_key}.md")

        print(f"\n  Distribuição por área:")
        for area_key, total in global_stats.items():
            if total > 0:
                print(f"    {self.question_processor.areas[area_key]['titulo']:<35} {total:>4} questão(ões)")

    def _exibir_relatorio(self):
        print(f"\n{'='*60}")
        print(f"  RELATÓRIO FINAL")
        print(f"{'='*60}")
        total          = len(self.results)
        com_erro       = sum(1 for r in self.results if r.erro)
        salvos         = sum(1 for r in self.results if r.salvo)
        total_limpezas = sum(len(r.limpezas) for r in self.results)
        chars_saved    = sum(r.chars_antes - r.chars_depois for r in self.results if not r.erro)

        print(f"  Arquivos processados : {total}")
        print(f"  Arquivos salvos      : {salvos}")
        print(f"  Erros                : {com_erro}")
        print(f"  Total de limpezas    : {total_limpezas}")
        print(f"  Chars removidos      : {chars_saved:,}")
        print(f"{'='*60}\n")


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────
def main():
    import argparse

    parser = argparse.ArgumentParser(
        prog="md_cleaner.py",
        description="Pipeline de limpeza, encoding e extração jurídica para arquivos Markdown",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""
        Exemplos:
          # Limpar todos os .md de uma pasta
          python md_cleaner.py /minha/pasta

          # Preview com visualização das mudanças (sem salvar)
          python md_cleaner.py /minha/pasta --dry-run

          # Ver exatamente o que vai mudar (diff colorido)
          python md_cleaner.py /minha/pasta --diff

          # Limpar e ver diff ao mesmo tempo
          python md_cleaner.py /minha/pasta --diff --sem-questoes

          # Monitorar pasta continuamente
          python md_cleaner.py /minha/pasta --watch

          # Monitorar com diff de cada arquivo ao ser modificado
          python md_cleaner.py /minha/pasta --watch --diff

          # Gerar relatório JSON
          python md_cleaner.py /minha/pasta --relatorio saida.json

          # Gerar relatório HTML auditável
          python md_cleaner.py /minha/pasta --html relatorio.html

          # Sufixo personalizado para arquivos limpos
          python md_cleaner.py /minha/pasta --sufixo _normalizado

          # Adicionar áreas jurídicas sem editar o código:
          # crie /minha/pasta/areas_extra.json e rode normalmente
          python md_cleaner.py /minha/pasta
        """),
    )

    parser.add_argument("diretorio", nargs="?", default=".", help="Diretório com arquivos .md")
    parser.add_argument("--dry-run",      action="store_true", help="Preview sem salvar arquivos")
    parser.add_argument("--diff",         action="store_true", help="Exibe diff colorido das mudanças")
    parser.add_argument("--watch",        action="store_true", help="Monitora pasta continuamente (requer watchdog)")
    parser.add_argument("--sem-questoes", action="store_true", help="Pula extração de questões jurídicas")
    parser.add_argument("--relatorio",    metavar="ARQUIVO",   help="Salva relatório JSON em arquivo")
    parser.add_argument("--html",         metavar="ARQUIVO",   help="Salva relatório HTML em arquivo")
    parser.add_argument("--sufixo",       default="_limpo",    help="Sufixo dos arquivos de saída (padrão: _limpo)")
    parser.add_argument("-v", "--verbose",action="store_true", help="Saída detalhada")

    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)

    base_dir = Path(args.diretorio).resolve()
    if not base_dir.exists():
        print(f"[ERRO] Diretório não encontrado: {base_dir}")
        sys.exit(1)

    orchestrator = PipelineOrchestrator(
        base_dir,
        dry_run=args.dry_run,
        sufixo=args.sufixo,
    )

    # [MELHORIA 4] Modo watch — ignora flags de execução única
    if args.watch:
        orchestrator.iniciar_watch(show_diff=args.diff)
        return

    # Execução única
    orchestrator.run(
        extrair_questoes=not args.sem_questoes,
        show_diff=args.diff,
    )

    if args.relatorio:
        orchestrator.salvar_relatorio_json(args.relatorio)

    # [MELHORIA 5] Relatório HTML
    if args.html:
        orchestrator.salvar_relatorio_html(args.html)


if __name__ == "__main__":
    main()
