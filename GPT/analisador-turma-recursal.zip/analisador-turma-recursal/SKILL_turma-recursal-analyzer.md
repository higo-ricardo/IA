---
name: turma-recursal-analyzer
description: >
  Analisa decisões judiciais da Turma Recursal Cível e Criminal de Chapadinha/MA (e turmas similares),
  identificando padrões estruturais, teses jurídicas, fundamentos de inadmissão/não conhecimento e
  consequências decisórias. Use esta skill SEMPRE que o usuário pedir para: analisar decisão de recurso
  extraordinário (Rext), agravo em recurso extraordinário (AG Rext), embargos de declaração (ED) ou
  qualquer decisão monocrática de turma recursal; verificar padrões de inadmissão de recursos; extrair
  dados processuais (partes, advogados, relator, comarca, tese, fundamento, resultado); redigir minutas
  de decisão baseadas em precedentes da turma; comparar múltiplas decisões; identificar se há repercussão
  geral, prequestionamento, erro grosseiro ou outro óbice recursal. Ative mesmo que o usuário não use
  termos técnicos — frases como "analisa essa decisão", "o que diz esse processo", "monta uma decisão
  parecida", "quais os padrões das decisões" também devem disparar esta skill.
---

# Turma Recursal – Analisador de Decisões Judiciais

## Contexto

Esta skill foi construída com base em decisões reais da **Turma Recursal Cível e Criminal de Chapadinha/MA**,
abrangendo três tipos principais de decisão:

1. **Rext** – Recurso Extraordinário (admissibilidade / inadmissão)
2. **AG Rext** – Agravo contra decisão que inadmitiu o Rext
3. **ED / ED AG Rext** – Embargos de Declaração contra decisão monocrática (de Rext ou AG)

---

## Estrutura-Padrão das Decisões (Template Identificado)

Todas as decisões seguem este esqueleto:

```
CABEÇALHO
  - Estado do Maranhão / Poder Judiciário
  - Turma Recursal Cível e Criminal de Chapadinha
  - Processo Nº [NNNNNNN-DD.AAAA.8.10.CCCC]
  - Origem: Comarca de [X]
  - Recorrente: [Nome] / Advogado: [Nome – OAB/UF NNNNN]
  - Recorrido(a): [Nome] / Advogado: [Nome – OAB/UF NNNNN]
  - Relator(a): Juíza [Nome]

RELATÓRIO (1–3 parágrafos)
  - Tipo de recurso interposto
  - Decisão atacada (Id. do documento)
  - Tese/argumento do recorrente (artigos CF alegados)

ADMISSIBILIDADE EXTRÍNSECA
  - "Examinando os requisitos extrínsecos... estão presentes" (ou não)

ADMISSIBILIDADE INTRÍNSECA / MÉRITO DA INADMISSÃO
  - Fundamento principal (um ou mais dos óbices abaixo)

DISPOSITIVO
  - Fórmula de inadmissão / não conhecimento
  - Determinações de secretaria
  - Local, data, assinatura da relatora
```

---

## Mapeamento Tese → Fundamento → Consequência

### TIPO 1 — Rext Inadmitido (mais comum)

| Tese do Recorrente | Fundamento da Inadmissão | Dispositivo |
|---|---|---|
| Alegação genérica de violação constitucional (art. 5º, 7º, 37, 169 CF etc.) | Ausência de repercussão geral — Temas 798, 800 e 660/STF; ARE 835833 | INADMITE-SE o Rext — art. 1.030, I, "a", CPC |
| Afirmação de repercussão geral sem justificação concreta | Preliminar genérica; ausência de indicação de relevância econômica, política, social ou jurídica | INADMITE-SE o Rext — art. 1.030, I, "a", CPC |
| Reexame de fatos e provas disfarçado de questão constitucional | Vedação da Súmula 279/STF; ofensa reflexa (Tema 660) | INADMITE-SE o Rext — art. 1.030, I, "a", CPC |
| Falta de embargos de declaração antes do Rext | Ausência de prequestionamento formal (art. 1.025 CPC); prequestionamento ficto não aplicado | INADMITE-SE o Rext — art. 1.030, I, "a", CPC |

### TIPO 2 — AG Rext Não Conhecido

| Situação | Fundamento | Dispositivo |
|---|---|---|
| Agravo interposto diretamente ao STF contra decisão que inadmitiu Rext por ausência de repercussão geral | Art. 1.042 CPC — não cabe agravo ao STF quando a inadmissão foi fundada em repercussão geral; recurso cabível era o agravo interno (art. 1.030, §2º c/c art. 1.021 CPC); erro grosseiro impede fungibilidade | DEIXO DE CONHECER o agravo — ausência de previsão legal; ARE 1505073/MA (STF) |

### TIPO 3 — ED Não Acolhidos / Rejeitados

| Situação | Fundamento | Dispositivo |
|---|---|---|
| ED contra decisão monocrática de Rext bem fundamentada | Inexistência de omissão, obscuridade, contradição ou erro; art. 1.022 CPC e art. 48 Lei 9.099/95 | CONHEÇO, mas REJEITO os embargos |
| ED com finalidade exclusiva de prequestionamento | Enunciado nº 125 do FONAJE | CONHEÇO, mas REJEITO |
| ED que pretende rediscutir mérito / inconformismo | Extrapola limites do art. 48 Lei 9.099/95 e 1.022 CPC | CONHEÇO, mas REJEITO |

---

## Precedentes e Temas STF Recorrentes

| Referência | Conteúdo |
|---|---|
| **Tema 798** | Presunção relativa de inexistência de repercussão geral em Rext de Juizados Especiais |
| **Tema 800 / ARE 835833** | Presunção de ausência de repercussão geral — Juizados (Lei 9.099/95); exige prequestionamento e repercussão geral efetivos |
| **Tema 660** | Ofensa reflexa — alegação que depende de reexame de legislação infraconstitucional não é direta à CF |
| **Súmula 279/STF** | Vedação ao reexame de fatos e provas em Rext |
| **Art. 1.030, I, "a", CPC** | Base legal da inadmissão por repercussão geral |
| **Art. 1.030, §2º c/c 1.021, CPC** | Recurso cabível contra inadmissão por rep. geral: agravo interno |
| **Art. 1.042, CPC** | Agravo ao STF — não cabe quando inadmissão se baseia em repercussão geral |
| **Enunciado 125 FONAJE** | ED não cabe com finalidade exclusiva de prequestionamento |
| **ARE 1505073/MA (STF)** | Precedente específico da Turma Recursal de Chapadinha — não cabe agravo ao STF |
| **Tema 1.241/STF** | Adicional de férias incide sobre todo o período de férias |

---

## Como Analisar uma Decisão (Passo a Passo)

### Ao receber um documento para análise:

1. **Extrair dados do cabeçalho**
   - Número do processo (padrão CNJ: `NNNNNNN-DD.AAAA.8.10.CCCC`)
   - Comarca de origem
   - Recorrente e advogado
   - Recorrido e advogado
   - Juíza relatora

2. **Classificar o tipo de decisão**
   - Rext direto → análise de admissibilidade
   - AG Rext → verifica se o agravo era cabível
   - ED → verifica vícios declaratórios

3. **Identificar a tese do recorrente**
   - Quais artigos da CF foram invocados
   - Qual o argumento central (repercussão geral, nulidade, inconstitucionalidade etc.)

4. **Identificar os óbices aplicados**
   - Ausência de repercussão geral (Temas 798/800)
   - Ofensa reflexa (Tema 660)
   - Reexame de fatos/provas (Súmula 279)
   - Ausência de prequestionamento
   - Erro grosseiro (para agravos)
   - Ausência de vícios declaratórios (para ED)

5. **Verificar o dispositivo**
   - INADMITE-SE / NEGA SEGUIMENTO (Rext)
   - DEIXA DE CONHECER (AG Rext)
   - REJEITA / NÃO ACOLHE (ED)

6. **Gerar resumo estruturado** no formato abaixo:

```
PROCESSO: [número]
TIPO: [Rext / AG Rext / ED]
RECORRENTE: [nome] (recorrente/réu/autor)
TESE: [resumo da alegação constitucional]
ÓBICES:
  - [óbice 1 + fundamento]
  - [óbice 2 + fundamento] (se houver)
RESULTADO: [INADMITIDO / NÃO CONHECIDO / REJEITADO]
BASE LEGAL: [art. X CPC / Tema Y STF]
RELATORA: [nome]
DATA: [data da decisão]
OBSERVAÇÕES: [ex.: ausência de prequestionamento, erro grosseiro, etc.]
```

---

## Como Redigir Minutas de Decisão

### Para INADMITIR Rext por ausência de repercussão geral:

Use este bloco de dispositivo padrão:

> "ISTO POSTO, à luz do precedente firmado pelo Supremo Tribunal Federal no ARE 835.833 (Tema 800), bem como considerando que a controvérsia não veicula questão constitucional direta, mas demanda o reexame de fatos e provas — providência vedada pela Súmula 279 do STF —, e encontra-se alinhada às diretrizes fixadas nos Temas 660, 798 e 800 do STF, conclui-se pela inexistência de repercussão geral. Assim, com fundamento no art. 1.030, I, alínea 'a', do Código de Processo Civil, **INADMITE-SE o Recurso Extraordinário, negando-lhe seguimento.**"

### Para NÃO CONHECER de AG Rext por erro grosseiro:

> "Desse modo, **deixo de conhecer** o presente agravo, por ausência de previsão legal."

### Para REJEITAR ED:

> "Diante do exposto, **conheço dos embargos de declaração, mas os rejeito**."

---

## Padrões de Nomenclatura dos Arquivos

Os arquivos seguem convenção com metadados no nome:

```
[TIPO]_[Nº CNJ]_Decisão_[partes]_[motivo]_[resultado].docx

Exemplos:
- Rext_0803523-47_2024_8_10_0048_Decisão_aus_reperc_geral_acórdão_rext_NEGADO.docx
- AG_Rext_0803673-62_2024_8_10_0069_Decisão_agravo_aus_repec_erro_grosseiro_N_CONHECIDO.doc
- ED_Ag_Rext_0800021-03_2025_8_10_0069_Decisão_ed_contra_monoc_aus_vícios_N_ACOLHIDOS.docx
```

Legenda:
- `aus_reperc_geral` = ausência de repercussão geral
- `redisc_mérito` = tentativa de rediscussão de mérito
- `aus_prequest` = ausência de prequestionamento
- `erro_grosseiro` = erro grosseiro recursal
- `aus_previsão` = ausência de previsão legal para o recurso
- `aus_vícios` = ausência de vícios declaratórios
- `NEGADO` / `N_CONHECIDO` / `N_ACOLHIDOS` = resultado

---

## Relatoras Identificadas

| Nome | Ocorrências |
|---|---|
| Juíza **Lyanne Pompeu de Sousa Brasil** | Maioria das decisões (Rext, AG, ED) |
| Juíza **Mirella Cezar Freitas** | Decisões com acórdão / ED rejeitado |

---

## Alertas e Casos Especiais

- **Prequestionamento**: se não houver ED antes do Rext, há óbice adicional (ausência de prequestionamento formal). Citar art. 1.025 CPC e a inexistência de embargos declaratórios.
- **Acórdão vs. decisão monocrática**: quando o Rext é contra acórdão colegiado, não há necessidade de prequestionamento via ED.
- **Municipios recorrentes**: frequentemente interpõem Rext alegando violação ao princípio da legalidade (remuneração de servidores). O óbice principal é ausência de repercussão geral + reexame de fatos.
- **ARE 1505073/MA**: precedente específico do STF sobre agravos oriundos desta própria Turma Recursal — citar quando AG for interposto diretamente ao STF.
